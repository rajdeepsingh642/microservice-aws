import React from 'react';

const Profile = () => {
  return (
    <div>
      <h2>Profile</h2>
      <p>Work in progress.</p>
    </div>
  );
};

export default Profile;
