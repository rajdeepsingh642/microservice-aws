import React from 'react';

const Products = () => {
  return (
    <div>
      <h2>Products</h2>
      <p>Work in progress.</p>
    </div>
  );
};

export default Products;
