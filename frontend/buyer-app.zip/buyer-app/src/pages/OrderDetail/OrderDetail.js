import React from 'react';

const OrderDetail = () => {
  return (
    <div>
      <h2>Order Detail</h2>
      <p>Work in progress.</p>
    </div>
  );
};

export default OrderDetail;
