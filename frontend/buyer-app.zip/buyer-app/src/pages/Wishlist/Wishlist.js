import React from 'react';

const Wishlist = () => {
  return (
    <div>
      <h2>Wishlist</h2>
      <p>Work in progress.</p>
    </div>
  );
};

export default Wishlist;
