import React, { useState, useEffect } from 'react';
import {
  Container,
  Typography,
  Box,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  Chip,
  IconButton,
  Avatar,
  LinearProgress,
  Tooltip,
  Rating
} from '@mui/material';
import {
  ShoppingCart,
  LocalOffer,
  Favorite,
  Visibility,
  ArrowForward,
  Compare
} from '@mui/icons-material';
import { useNavigate } from 'react-router-dom';
import { productsAPI } from '../../services/api';
import { addToWishlist } from '../../store/slices/wishlistSlice';
import { addToCartStart, addToCartSuccess, addToCartFailure } from '../../store/slices/cartSlice';
import { useDispatch, useSelector } from 'react-redux';
import toast from 'react-hot-toast';
import ProductImage from '../../components/ProductImage/ProductImage';

const Home = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { isAuthenticated } = useSelector((state) => state.auth);
  
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load data from API
    const loadData = async () => {
      try {
        setLoading(true);
        
        // Fetch products from API
        const productsResponse = await productsAPI.getProducts();
        const rawProducts =
          productsResponse?.data?.products ||
          productsResponse?.data?.data ||
          productsResponse?.data?.items ||
          [];

        const enhancedProducts = (Array.isArray(rawProducts) ? rawProducts : []).map(product => ({
          ...product,
          discount: Math.random() > 0.5 ? Math.floor(Math.random() * 50) + 10 : 0,
          badge: Math.random() > 0.7 ? 'Bestseller' : Math.random() > 0.5 ? 'Hot Deal' : null,
          rating: 4.2 + Math.random() * 0.8,
          reviews: Math.floor(Math.random() * 500) + 50,
          delivery: Math.random() > 0.5 ? 'Free Delivery' : 'Express Delivery',
          seller: {
            name: `Seller${Math.floor(Math.random() * 100)}`,
            rating: 4.0 + Math.random(),
            location: 'Mumbai, India'
          }
        }));

        setProducts(enhancedProducts);

        setLoading(false);
      } catch (error) {
        console.error('Error loading data:', error);
        setLoading(false);
      }
    };

    loadData();
  }, []);

  const handleAddToCart = (product, e) => {
    e.stopPropagation();
    
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    dispatch(addToCartStart());
    
    try {
      const cartItem = {
        _id: product._id || product.id,
        productId: product._id || product.id,
        name: product.name,
        price: product.discount ? product.price * (1 - product.discount / 100) : product.price,
        originalPrice: product.price,
        discount: product.discount,
        image: product.images?.[0]?.url,
        quantity: 1,
        stock: product.stock || 10
      };
      
      dispatch(addToCartSuccess(cartItem));
      toast.success(`${product.name} added to cart!`);
    } catch (error) {
      dispatch(addToCartFailure(error.message));
      toast.error('Failed to add to cart');
    }
  };

  const handleAddToWishlist = (product, e) => {
    e.stopPropagation();
    
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    dispatch(addToWishlist({
      productId: product._id || product.id,
      name: product.name,
      price: product.price,
      image: product.images?.[0]?.url,
    }));
    toast.success(`${product.name} added to wishlist!`);
  };

  const handleQuickView = (productId) => {
    navigate(`/product/${productId}`);
  };

  const ProductCard = ({ product }) => (
    <Card
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        cursor: 'pointer',
        transition: 'all 0.3s ease',
        position: 'relative',
        '&:hover': {
          transform: 'translateY(-8px)',
          boxShadow: '0 8px 24px rgba(0,0,0,0.15)',
        },
      }}
      onClick={() => handleQuickView(product._id)}
    >
      {/* Discount Badge */}
      {product.discount && (
        <Box
          sx={{
            position: 'absolute',
            top: 10,
            left: 10,
            zIndex: 2,
          }}
        >
          <Chip
            label={`${product.discount}% OFF`}
            color="error"
            size="small"
            sx={{
              fontWeight: 'bold',
              fontSize: '0.75rem',
            }}
          />
        </Box>
      )}

      {/* Product Badge */}
      {product.badge && (
        <Box
          sx={{
            position: 'absolute',
            top: 10,
            right: 10,
            zIndex: 2,
          }}
        >
          <Chip
            label={product.badge}
            color="warning"
            size="small"
            sx={{
              fontWeight: 'bold',
              fontSize: '0.75rem',
            }}
          />
        </Box>
      )}

      {/* Product Image */}
      <Box sx={{ position: 'relative' }}>
        <ProductImage
          images={product.images}
          alt={product.name}
          height={200}
        />
        
        {/* Quick Actions */}
        <Box
          sx={{
            position: 'absolute',
            top: 10,
            right: 10,
            display: 'flex',
            gap: 0.5,
            opacity: 0,
            transition: 'opacity 0.2s ease',
          }}
          className="quick-actions"
        >
          <Tooltip title="Quick View">
            <IconButton size="small" sx={{ bgcolor: 'white', '&:hover': { bgcolor: 'grey.100' } }}>
              <Visibility fontSize="small" />
            </IconButton>
          </Tooltip>
          
          <Tooltip title="Add to Wishlist">
            <IconButton size="small" sx={{ bgcolor: 'white', '&:hover': { bgcolor: 'grey.100' } }}>
              <Favorite fontSize="small" />
            </IconButton>
          </Tooltip>
          
          <Tooltip title="Compare">
            <IconButton size="small" sx={{ bgcolor: 'white', '&:hover': { bgcolor: 'grey.100' } }}>
              <Compare fontSize="small" />
            </IconButton>
          </Tooltip>
        </Box>
      </Box>

      <CardContent sx={{ flexGrow: 1, pb: 1 }}>
        {/* Product Title */}
        <Typography variant="h6" component="div" sx={{ mb: 1, lineHeight: 1.2 }}>
          {product.name}
        </Typography>

        {/* Rating and Reviews */}
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <Rating
            value={product.rating}
            precision={0.5}
            readOnly
            size="small"
            sx={{ color: '#ff9800' }}
          />
          <Typography variant="body2" color="text.secondary" sx={{ ml: 1 }}>
            ({product.reviews} reviews)
          </Typography>
        </Box>

        {/* Delivery Info */}
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
          <LocalOffer fontSize="small" sx={{ mr: 0.5, color: '#4caf50' }} />
          <Typography variant="body2" color="text.secondary">
            {product.delivery}
          </Typography>
        </Box>

        {/* Price */}
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Typography variant="h5" color="primary.main" fontWeight="bold">
            ₹{Math.floor(product.price * 83)} {/* Convert to INR */}
          </Typography>
          {product.originalPrice > product.price && (
            <Typography variant="body2" color="text.secondary" sx={{ ml: 1, textDecoration: 'line-through' }}>
              ₹{Math.floor(product.originalPrice * 83)}
            </Typography>
          )}
        </Box>

        {/* Seller Info */}
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
          <Avatar sx={{ width: 24, height: 24, mr: 1, bgcolor: 'primary.main' }}>
            {product.seller.name.charAt(0)}
          </Avatar>
          <Box sx={{ flexGrow: 1 }}>
            <Typography variant="body2" fontWeight="medium">
              {product.seller.name}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {product.seller.location} • {product.seller.rating} ⭐
            </Typography>
          </Box>
        </Box>
      </CardContent>

      <CardActions sx={{ p: 2, flexDirection: 'column', gap: 1 }}>
        <Button
          variant="contained"
          fullWidth
          startIcon={<ShoppingCart />}
          onClick={(e) => handleAddToCart(product, e)}
          sx={{
            bgcolor: '#ff6f00',
            '&:hover': { bgcolor: '#ff8f00' },
          }}
        >
          Add to Cart
        </Button>
        
        <Box sx={{ display: 'flex', gap: 1 }}>
          <Button
            variant="outlined"
            size="small"
            startIcon={<Favorite />}
            onClick={(e) => handleAddToWishlist(product, e)}
          >
            Wishlist
          </Button>
          
          <Button
            variant="outlined"
            size="small"
            startIcon={<ArrowForward />}
            onClick={() => handleQuickView(product._id)}
          >
            View
          </Button>
        </Box>
      </CardActions>
    </Card>
  );

  if (loading) {
    return (
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Typography variant="h4" gutterBottom>
          Flipkart Style E-commerce
        </Typography>
        
        <LinearProgress sx={{ mb: 4 }} />
        <Typography variant="body2" color="text.secondary" align="center">
          Loading amazing products for you...
        </Typography>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ py: 4 }}>
      <Box mb={4}>
        <Typography variant="h3" gutterBottom>
          Welcome to E-commerce Marketplace
        </Typography>
        <Typography variant="h6" color="text.secondary">
          Discover amazing products from sellers around the world
        </Typography>
      </Box>

      <Typography variant="h4" gutterBottom>
        Featured Products ({products?.length || 0})
      </Typography>

      {/* Test: Show basic content first */}
      <Box sx={{ p: 2, bgcolor: 'grey.100', mb: 2, borderRadius: 1 }}>
        <Typography>Debug: Products count = {products?.length || 0}</Typography>
        <Typography>Debug: First product = {products?.[0]?.name || 'None'}</Typography>
      </Box>

      <Grid container spacing={3}>
        {products?.map((product) => (
          <Grid item xs={12} sm={6} md={4} lg={3} key={product._id}>
            <ProductCard product={product} />
          </Grid>
        ))}
      </Grid>

      {(!products || products.length === 0) && (
        <Box textAlign="center" py={4}>
          <Typography variant="h6" color="text.secondary">
            No featured products available at the moment.
          </Typography>
        </Box>
      )}
    </Container>
  );
};

export default Home;
